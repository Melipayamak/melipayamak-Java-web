package controllers;

import akka.actor.ActorSystem;
import javax.inject.*;
import play.mvc.*;
import play.libs.ws.*;
import java.util.concurrent.CompletionStage;
import scala.concurrent.ExecutionContextExecutor;

import services.SoapClient;
import services.RestClient;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    private final ActorSystem actorSystem;
    private final ExecutionContextExecutor exec;

    RestClient rest;
    SoapClient soap;

    String username = "username";
    String password = "password";
    String to = "09123456789";
    String from = "5000...";
    String text = "play framework test";
    boolean isFlash = false;

    @Inject
    public HomeController(ActorSystem actorSystem, ExecutionContextExecutor exec,  WSClient ws) {
      this.actorSystem = actorSystem;
      this.exec = exec;
      this.rest = new RestClient(ws);
      this.soap = new SoapClient(ws);
    }

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    public Result index() {
        return ok(views.html.index.render());
    }
    
    public Result explore() {
        return ok(views.html.explore.render());
    }
    
    public Result tutorial() {
        return ok(views.html.tutorial.render());
    }


    //SMS
    public CompletionStage<Result> rest() {
        rest.initCred(username, password);
        return rest.SendSMS(to, from, text, isFlash).thenApplyAsync(response -> ok(response.asJson()), exec);        
    }

    public CompletionStage<Result> soap() {
        soap.initCred(username, password);
        return soap.SendSimpleSMS2(to, from, text, isFlash).thenApplyAsync(response -> ok(response.getBody()), exec);        
    }

}
